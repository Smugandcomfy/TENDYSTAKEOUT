# Launchpad-interface

TENDY TAKE OUT
launchpad for tokens beta 1.0

special thanks to icpswap crew for making the source code for this project. 
s
this is the interface component of The Tendy Take Out token launchpad. hopefully this will be a working begining to some software services within the peecosystem. 

this is my first ever fork and edit of a software on git hub -vp
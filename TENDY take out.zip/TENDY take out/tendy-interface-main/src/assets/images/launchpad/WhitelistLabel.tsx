export default function WhitelistLabel() {
  return (
    <svg width="59" height="56" viewBox="0 0 59 56" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M33.875 0L59 23.5V56L0 0H33.875Z" fill="white" fillOpacity="0.1" />
    </svg>
  );
}

export default interface _SERVICE {
  totalSupply: () => Promise<bigint>;
}

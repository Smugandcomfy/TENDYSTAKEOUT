export const XTCCanisterId = "aanaa-xaaaa-aaaah-aaeiq-cai";

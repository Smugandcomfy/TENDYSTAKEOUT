module.exports = {
  port: 8000,
  host: "http://localhost",
};

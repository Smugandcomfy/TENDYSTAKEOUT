const canisterIds: { [key: string]: string } = {};

export const WICPCanisterId = "5xnja-6aaaa-aaaan-qad4a-cai";

export const ALL_CANISTER_IDS = [WICPCanisterId];

export { canisterIds };

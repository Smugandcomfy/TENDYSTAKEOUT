export const SNS1_ID = "zfcdd-tqaaa-aaaaq-aaaga-cai";

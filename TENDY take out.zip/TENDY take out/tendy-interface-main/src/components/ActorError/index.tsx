// import { useInitialActorError } from "hooks/useActorError";
import React from "react";

export default function ActorError({ children }: { children: React.ReactNode }) {
  // useInitialActorError();

  return <>{children}</>;
}

export enum SortDirection {
  ASC = "asc",
  DESC = "desc",
}

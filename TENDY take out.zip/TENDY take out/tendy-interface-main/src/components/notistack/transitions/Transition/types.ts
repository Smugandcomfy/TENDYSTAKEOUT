export enum TransitionStatus {
  UNMOUNTED = "unmounted",
  EXITED = "exited",
  ENTERING = "entering",
  ENTERED = "entered",
  EXITING = "exiting",
}

export * from "./Slide";
export { default } from "./Slide";

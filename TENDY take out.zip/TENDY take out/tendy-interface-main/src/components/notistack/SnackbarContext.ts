import React from "react";
import { ProviderContext } from "./types";

export default React.createContext<ProviderContext>({} as ProviderContext);
